// ADCTestMain.c
// Runs on TM4C1294
// This program periodically samples ADC channel 8 and 9 and
// store the results to global variables that can be accessed
// with the JTAG debugger and viewed with the variable watch
// feature.
// Daniel Valvano
// April 14, 2014

/* This example accompanies the book
   "Embedded Systems: Real Time Interfacing to Arm Cortex M Microcontrollers",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2014

 Copyright 2014 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */

// center of two X-ohm potentiometers connected to PE5/AIN8 and PE4/AIN9
// bottom of X-ohm potentiometers connected to ground
// top of X-ohm potentiometers connected to +3.3V
#include <stdint.h>
#include "ADCSWTrigger.h"
#include "tm4c1294ncpdt.h"
#include "PLL.h"

#define GPIO_PORTN1             (*((volatile uint32_t *)0x40064008))

void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void);  // Enable interrupts
long StartCritical(void);     // previous I bit, disable interrupts
void EndCritical(long sr);    // restore I bit to previous value
void WaitForInterrupt(void);  // low power mode

uint32_t ADCvalue[2];
// data returned from ADC0_InSeq2() by reference
// ADCvalue[0] is second result (default: ADC8 (PE5)) 0 to 4095
// ADCvalue[1] is first result  (default: ADC9 (PE4)) 0 to 4095

// This debug function initializes Timer0A to request interrupts
// at a 10 Hz frequency.  It is similar to FreqMeasure.c.
void Timer0A_Init10HzInt(void){
  DisableInterrupts();
  // **** general initialization ****
                                   // activate timer0
  SYSCTL_RCGCTIMER_R |= SYSCTL_RCGCTIMER_R0;
                                   // allow time for clock to stabilize
  while((SYSCTL_PRTIMER_R&SYSCTL_PRTIMER_R0) == 0){};
  TIMER0_CTL_R &= ~TIMER_CTL_TAEN; // disable timer0A during setup
  TIMER0_CFG_R = TIMER_CFG_16_BIT; // configure for 16-bit timer mode
  TIMER0_CC_R &= ~TIMER_CC_ALTCLK; // timer0 clocked from system clock
  // **** timer0A initialization ****
                                   // configure for periodic mode
  TIMER0_TAMR_R = TIMER_TAMR_TAMR_PERIOD;
  TIMER0_TAPR_R = 199;             // prescale value for 10us
  TIMER0_TAILR_R = 59999;          // start value for 10 Hz interrupts
  TIMER0_IMR_R |= TIMER_IMR_TATOIM;// enable timeout (rollover) interrupt
  TIMER0_ICR_R = TIMER_ICR_TATOCINT;// clear timer0A timeout flag
  TIMER0_CTL_R |= TIMER_CTL_TAEN;  // enable timer0A 16-b, periodic, interrupts
  // **** interrupt initialization ****
                                   // Timer0A=priority 2
  NVIC_PRI4_R = (NVIC_PRI4_R&0x00FFFFFF)|0x40000000; // top 3 bits
  NVIC_EN0_R = 0x00080000;         // enable interrupt 19 in NVIC
}
void Timer0A_Handler(void){
  TIMER0_ICR_R = TIMER_ICR_TATOCINT;    // acknowledge timer0A timeout
  GPIO_PORTN1 ^= 0x02;                  // profile
  ADC0_InSeq2(ADCvalue);                // takes 3.4 usec to run
//  GPIO_PORTN1 = 0x00;
}
int main(void){
  PLL_Init();                      // 120 MHz
                                   // activate clock for Port N
  SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R12;
                                   // allow time for clock to stabilize
  while((SYSCTL_PRGPIO_R&SYSCTL_PRGPIO_R12) == 0){};
  ADC0_InitSWTriggerSeq2_Ch89();   // initialize ADC0, software trigger, PE5/AIN8 and PE4/AIN9
  Timer0A_Init10HzInt();           // set up Timer0A for 10 Hz interrupts
  GPIO_PORTN_DIR_R |= 0x02;        // make PN1 out (PN1 built-in LED1)
  GPIO_PORTN_AFSEL_R &= ~0x02;     // disable alt funct on PN1
  GPIO_PORTN_DEN_R |= 0x02;        // enable digital I/O on PN1
                                   // configure PN1 as GPIO
  GPIO_PORTN_PCTL_R = (GPIO_PORTN_PCTL_R&0xFFFFFF0F)+0x00000000;
  GPIO_PORTN_AMSEL_R &= ~0x02;     // disable analog functionality on PN1
  EnableInterrupts();
  while(1){
    WaitForInterrupt();
  }
}
